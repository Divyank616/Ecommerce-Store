SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


-- Customer Table
CREATE TABLE Customer (
    Customer_id INT AUTO_INCREMENT PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Contact_no VARCHAR(15) UNIQUE NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    House_No VARCHAR(10),
    Local_Area VARCHAR(100),
    Pin_Code VARCHAR(10),
    City VARCHAR(50)
);

-- Coupon Table
CREATE TABLE Coupon (
    Coupon_id INT AUTO_INCREMENT PRIMARY KEY,
    Discount_percentage DECIMAL(5,2) NOT NULL CHECK (Discount_percentage BETWEEN 0 AND 100)
);

-- Cart Table
CREATE TABLE Cart (
    Customer_id INT PRIMARY KEY,
    Total_product INT CHECK (Total_product >= 0),
    Total_cost DECIMAL(10,2) CHECK (Total_cost >= 0),
    Coupon_id INT,
    FOREIGN KEY (Customer_id) REFERENCES Customer(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (Coupon_id) REFERENCES Coupon(Coupon_id) ON DELETE SET NULL
);

-- Orders Table
CREATE TABLE Orders (
    Order_id INT AUTO_INCREMENT PRIMARY KEY,
    Tax DECIMAL(5,2) CHECK (Tax >= 0),
    Order_cost DECIMAL(10,2) CHECK (Order_cost >= 0),
    Discount_percentage DECIMAL(5,2) CHECK (Discount_percentage BETWEEN 0 AND 100)
);

-- Employee Table
CREATE TABLE Employee (
    Employee_id INT AUTO_INCREMENT PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Department VARCHAR(50),
    City VARCHAR(50),
    Pin_Code VARCHAR(10),
    House_No VARCHAR(10),
    Local_Area VARCHAR(100),
    Date_of_Joining DATE,
    Age INT CHECK (Age > 18),
    Date_of_Birth DATE,
    Gender VARCHAR(10) CHECK (Gender IN ('Male', 'Female', 'Other'))
);

-- Vendor Table
CREATE TABLE Vendor (
    Vendor_id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Contact_No VARCHAR(15) NOT NULL,
    City VARCHAR(50),
    Local_Area VARCHAR(100),
    Pin_Code VARCHAR(10)
);

-- Product Table
CREATE TABLE Product (
    Product_id INT AUTO_INCREMENT PRIMARY KEY,
    Price DECIMAL(10,2) CHECK (Price >= 0),
    Details TEXT,
    Photos TEXT,
    Category VARCHAR(50),
    Ratings DECIMAL(3,2) CHECK (Ratings BETWEEN 0 AND 5),
    Discount_percentage DECIMAL(5,2) CHECK (Discount_percentage BETWEEN 0 AND 100),
    GST DECIMAL(5,2) CHECK (GST >= 0)
);

-- Clothing Table
CREATE TABLE Clothing (
    Product_id INT PRIMARY KEY,
    Fabric VARCHAR(50),
    Gender VARCHAR(10) CHECK (Gender IN ('Male', 'Female', 'Unisex')),
    Size VARCHAR(10),
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE
);

-- Groceries Table
CREATE TABLE Groceries (
    Product_id INT PRIMARY KEY,
    Use_By_date DATE,
    Weight DECIMAL(5,2) CHECK (Weight > 0),
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE
);

-- Electronics Table
CREATE TABLE Electronics (
    Product_id INT PRIMARY KEY,
    Warranty_Period INT CHECK (Warranty_Period >= 0),
    Manufacture_Date DATE,
    Manufacturing_City VARCHAR(50),
    Power_Requirement VARCHAR(50),
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE
);

-- WareHouse Table
CREATE TABLE WareHouse (
    Warehouse_id INT AUTO_INCREMENT PRIMARY KEY,
    Plot_No VARCHAR(10),
    City VARCHAR(50),
    Contact_No VARCHAR(15),
    Pin_Code VARCHAR(10)
);

-- DeliveryPartner Table
CREATE TABLE DeliveryPartner (
    Employee_id INT PRIMARY KEY,
    Vehicle_Type VARCHAR(50),
    Vehicle_No VARCHAR(20),
    FOREIGN KEY (Employee_id) REFERENCES Employee(Employee_id) ON DELETE CASCADE
);

-- Includes Table
CREATE TABLE Includes (
    Order_id INT,
    Product_id INT,
    Quantity INT CHECK (Quantity > 0),
    PRIMARY KEY (Order_id, Product_id),
    FOREIGN KEY (Order_id) REFERENCES Orders(Order_id) ON DELETE CASCADE,
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE
);

-- Transaction Table
CREATE TABLE Transaction (
    Order_id INT PRIMARY KEY,
    Status VARCHAR(50) CHECK (Status IN ('Pending', 'Completed', 'Failed')),
    Time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Customer_id INT,
    FOREIGN KEY (Order_id) REFERENCES Orders(Order_id) ON DELETE CASCADE,
    FOREIGN KEY (Customer_id) REFERENCES Customer(Customer_id) ON DELETE CASCADE
);

-- Supplies Table
CREATE TABLE Supplies (
    Vendor_id INT,
    Product_id INT,
    Quantity INT CHECK (Quantity > 0),
    PRIMARY KEY (Vendor_id, Product_id),
    FOREIGN KEY (Vendor_id) REFERENCES Vendor(Vendor_id) ON DELETE CASCADE,
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE
);

-- Delivery Table
CREATE TABLE Delivery (
    Order_id INT PRIMARY KEY,
    Customer_id INT,
    Warehouse_id INT,
    Employee_id INT,
    FOREIGN KEY (Order_id) REFERENCES Orders(Order_id) ON DELETE CASCADE,
    FOREIGN KEY (Customer_id) REFERENCES Customer(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (Warehouse_id) REFERENCES WareHouse(Warehouse_id) ON DELETE CASCADE,
    FOREIGN KEY (Employee_id) REFERENCES Employee(Employee_id) ON DELETE CASCADE
);

-- Complaints Table
CREATE TABLE Complaints (
    Complaint_No INT AUTO_INCREMENT PRIMARY KEY,
    Employee_id INT,
    Customer_id INT,
    Order_id INT,
    FOREIGN KEY (Employee_id) REFERENCES Employee(Employee_id) ON DELETE SET NULL,
    FOREIGN KEY (Customer_id) REFERENCES Customer(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (Order_id) REFERENCES Orders(Order_id) ON DELETE CASCADE
);

-- Stores Table
CREATE TABLE Stores (
    Product_id INT,
    Warehouse_id INT,
    Stocks INT CHECK (Stocks >= 0),
    PRIMARY KEY (Product_id, Warehouse_id),
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE,
    FOREIGN KEY (Warehouse_id) REFERENCES WareHouse(Warehouse_id) ON DELETE CASCADE
);

-- Contains Table
CREATE TABLE Contains (
    Customer_id INT,
    Product_id INT,
    Quantity INT,
    PRIMARY KEY (Customer_id, Product_id),
    FOREIGN KEY (Customer_id) REFERENCES Customer(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id) ON DELETE CASCADE
);
--
-- Dumping data for table `trig`
--
-- Insert into Customer
INSERT INTO Customer (First_Name, Last_Name, Contact_no, Email, Password, House_No, Local_Area, Pin_Code, City) VALUES
('John', 'Doe', '9876543210', 'john@example.com', 'hashed_password', 'A12', 'Green Street', '110001', 'New York'),
('Alice', 'Smith', '8765432109', 'alice@example.com', 'hashed_password2', 'B23', 'Blue Lane', '220002', 'Los Angeles'),
('Bob', 'Johnson', '7654321098', 'bob@example.com', 'hashed_password3', 'C34', 'Red Avenue', '330003', 'Chicago'),
('David', 'Brown', '6543219870', 'david@example.com', 'hashed_password4', 'D45', 'Yellow Road', '440004', 'Houston'),
('Emma', 'Wilson', '5432108765', 'emma@example.com', 'hashed_password5', 'E56', 'Orange Blvd', '550005', 'San Francisco');

-- Insert into Coupon
INSERT INTO Coupon (Discount_percentage) VALUES
(10.00), 
(15.00), 
(20.00),
(25.00),
(30.00);

-- Insert into Cart
INSERT INTO Cart (Customer_id, Total_product, Total_cost, Coupon_id) VALUES
(1, 3, 75.00, 1),
(2, 5, 120.00, 2),
(3, 2, 50.00, NULL),  
(4, 4, 90.00, 3),
(5, 6, 180.00, 4);

-- Insert into Orders
INSERT INTO Orders (Tax, Order_cost, Discount_percentage) VALUES
(5.00, 100.00, 10.00),
(7.50, 250.00, 15.00),
(6.00, 180.00, 5.00),
(4.50, 220.00, 20.00),
(8.00, 350.00, 25.00);

-- Insert into Employee
INSERT INTO Employee (First_Name, Last_Name, Email, Department, City, Pin_Code, House_No, Local_Area, Date_of_Joining, Age, Date_of_Birth, Gender) VALUES
('Michael', 'Scott', 'michael@dundermifflin.com', 'Sales', 'Scranton', '18503', 'D1', 'Business Park', '2005-04-15', 45, '1978-03-15', 'Male'),
('Pam', 'Beesly', 'pam@dundermifflin.com', 'Reception', 'Scranton', '18503', 'D1', 'Business Park', '2006-07-10', 32, '1991-06-25', 'Female'),
('Jim', 'Halpert', 'jim@dundermifflin.com', 'Sales', 'Scranton', '18503', 'D2', 'Business Park', '2004-02-15', 42, '1981-07-28', 'Male'),
('Dwight', 'Schrute', 'dwight@dundermifflin.com', 'Assistant Regional Manager', 'Scranton', '18503', 'D3', 'Business Park', '2001-05-01', 50, '1973-01-20', 'Male'),
('Angela', 'Martin', 'angela@dundermifflin.com', 'Accounting', 'Scranton', '18503', 'D4', 'Business Park', '2005-08-19', 40, '1983-09-25', 'Female');

-- Insert into Vendor
INSERT INTO Vendor (Name, Contact_No, City, Local_Area, Pin_Code) VALUES
('ABC Suppliers', '555-1234', 'New York', 'Manhattan', '10001'),
('XYZ Distributors', '555-5678', 'Los Angeles', 'Downtown', '90001'),
('LMN Traders', '555-4321', 'Chicago', 'Lakeview', '60001'),
('PQR Enterprises', '555-8765', 'San Francisco', 'Golden Gate', '94102'),
('STU Ventures', '555-2345', 'Houston', 'West End', '77002');

-- Insert into Product
INSERT INTO Product (Price, Details, Photos, Category, Ratings, Discount_percentage, GST) VALUES
(50.00, 'High-quality cotton t-shirt', 'tshirt.jpg', 'Clothing', 4.5, 10.00, 5.00),
(30.00, 'Organic apples, 1kg pack', 'apples.jpg', 'Groceries', 4.7, 5.00, 0.00),
(500.00, 'Wireless noise-canceling headphones', 'headphones.jpg', 'Electronics', 4.8, 15.00, 18.00),
(80.00, 'Leather wallet', 'wallet.jpg', 'Clothing', 4.2, 20.00, 5.00),
(25.00, 'Fresh strawberries, 500g pack', 'strawberries.jpg', 'Groceries', 4.9, 8.00, 0.00);

-- Insert into Clothing
INSERT INTO Clothing (Product_id, Fabric, Gender, Size) VALUES
(1, 'Cotton', 'Unisex', 'M'),
(4, 'Leather', 'Unisex', 'L');

-- Insert into Groceries
INSERT INTO Groceries (Product_id, Use_By_date, Weight) VALUES
(2, '2024-03-15', 1.00),
(5, '2024-02-28', 0.5);

-- Insert into Electronics
INSERT INTO Electronics (Product_id, Warranty_Period, Manufacture_Date, Manufacturing_City, Power_Requirement) VALUES
(3, 12, '2023-12-01', 'San Francisco', '5V DC');

-- Insert into WareHouse
INSERT INTO WareHouse (Plot_No, City, Contact_No, Pin_Code) VALUES
('W123', 'New York', '555-8888', '10001'),
('W456', 'Los Angeles', '555-9999', '90001'),
('W789', 'Chicago', '555-1111', '60001'),
('W101', 'San Francisco', '555-2222', '94102'),
('W202', 'Houston', '555-3333', '77002');

-- Insert into DeliveryPartner
INSERT INTO DeliveryPartner (Employee_id, Vehicle_Type, Vehicle_No) VALUES
(1, 'Bike', 'NY-1234'),
(2, 'Truck', 'LA-5678'),
(3, 'Van', 'SF-1010'),
(4, 'Bike', 'HOU-3030'),
(5, 'Truck', 'CHI-4040');

-- Insert into Includes
INSERT INTO Includes (Order_id, Product_id, Quantity) VALUES
(1, 1, 2),
(2, 2, 3),
(3, 3, 1),
(4, 4, 2),
(5, 5, 3);

-- Insert into Transaction
INSERT INTO Transaction (Order_id, Status, Time, Customer_id) VALUES
(1, 'Completed', CURRENT_TIMESTAMP, 1),
(2, 'Pending', CURRENT_TIMESTAMP, 2),
(3, 'Failed', CURRENT_TIMESTAMP, 3),
(4, 'Completed', CURRENT_TIMESTAMP, 4),
(5, 'Completed', CURRENT_TIMESTAMP, 5);

-- Insert into Supplies
INSERT INTO Supplies (Vendor_id, Product_id, Quantity) VALUES
(1, 1, 100),
(2, 2, 200),
(1, 3, 50),
(3, 4, 150),
(4, 5, 250);

-- Insert into Delivery
INSERT INTO Delivery (Order_id, Customer_id, Warehouse_id, Employee_id) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 3, 3, 3),
(4, 4, 4, 4),
(5, 5, 5, 5);

-- Insert into Complaints
INSERT INTO Complaints (Employee_id, Customer_id, Order_id) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5);

-- Insert into Stores
INSERT INTO Stores (Product_id, Warehouse_id, Stocks) VALUES
(1, 1, 500),
(2, 2, 300),
(3, 1, 150),
(4, 3, 600),
(5, 4, 100); 

-- Insert into Contains
INSERT INTO Contains (Customer_id, product_id, quantity) VALUES
(1, 1, 2),
(1, 2, 1),
(2, 3, 5),
(3, 4, 2),
(4, 5, 3);