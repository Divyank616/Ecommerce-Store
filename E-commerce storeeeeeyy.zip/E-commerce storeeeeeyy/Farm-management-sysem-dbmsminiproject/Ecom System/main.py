from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, logout_user, login_manager, LoginManager, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'ecommercekey'

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/E-Commerce'
db = SQLAlchemy(app)

# Login manager setup
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Role-based access control
def employee_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not isinstance(current_user, Employee):
            flash('Access denied. Employee login required.', 'danger')
            return redirect(url_for('employee_login'))
        return f(*args, **kwargs)
    return decorated_function

def vendor_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not isinstance(current_user, Vendor):
            flash('Access denied. Vendor login required.', 'danger')
            return redirect(url_for('vendor_login'))
        return f(*args, **kwargs)
    return decorated_function

@login_manager.user_loader
def load_user(user_id):
    # Check the user type from the session
    user_type = session.get('user_type')
    if user_type == 'customer':
        return Customer.query.get(int(user_id))
    elif user_type == 'employee':
        return Employee.query.get(int(user_id))
    elif user_type == 'vendor':
        return Vendor.query.get(int(user_id))
    return None

# Database Models
class Employee(UserMixin, db.Model):
    Employee_id = db.Column(db.Integer, primary_key=True)
    First_Name = db.Column(db.String(50), nullable=False)
    Last_Name = db.Column(db.String(50), nullable=False)
    Email = db.Column(db.String(100), unique=True, nullable=False)
    Department = db.Column(db.String(50), nullable=False)
    City = db.Column(db.String(50))
    Pin_Code = db.Column(db.String(10))
    House_No = db.Column(db.String(10))
    Local_Area = db.Column(db.String(100))
    Date_of_Joining = db.Column(db.Date)
    Age = db.Column(db.Integer)
    Date_of_Birth = db.Column(db.Date)
    Gender = db.Column(db.String(10))

    def get_id(self):
        return str(self.Employee_id)

class Vendor(UserMixin, db.Model):
    Vendor_id = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String(100), nullable=False)
    Contact_No = db.Column(db.String(15))
    City = db.Column(db.String(50))
    Local_Area = db.Column(db.String(100))
    Pin_Code = db.Column(db.String(10))

    def get_id(self):
        return str(self.Vendor_id)

class Complaint(db.Model):
    __tablename__ = 'complaints'
    Complaint_No = db.Column('Complaint_No', db.Integer, primary_key=True)
    Employee_id = db.Column('Employee_id', db.Integer, db.ForeignKey('employee.Employee_id'))
    Customer_id = db.Column('Customer_id', db.Integer, db.ForeignKey('customer.Customer_id'))
    Order_id = db.Column('Order_id', db.Integer, db.ForeignKey('orders.Order_id'))

    def __init__(self, Customer_id, Order_id=None):
        self.Customer_id = Customer_id
        self.Order_id = Order_id

class Customer(UserMixin, db.Model):
    Customer_id = db.Column(db.Integer, primary_key=True)
    First_Name = db.Column(db.String(50), nullable=False)
    Last_Name = db.Column(db.String(50), nullable=False)
    Contact_no = db.Column(db.String(15), unique=True, nullable=False)
    Email = db.Column(db.String(100), unique=True, nullable=False)
    Password = db.Column(db.String(255), nullable=False)
    House_No = db.Column(db.String(10))
    Local_Area = db.Column(db.String(100))
    Pin_Code = db.Column(db.String(10))
    City = db.Column(db.String(50))
    cart = db.relationship('Cart', backref='customer', uselist=False)

    def get_id(self):
        return str(self.Customer_id)

class Clothing(db.Model):
    Product_id = db.Column(db.Integer, db.ForeignKey('product.Product_id'), primary_key=True)
    Size = db.Column(db.String(10))
    Color = db.Column(db.String(20))
    Material = db.Column(db.String(50))
    product = db.relationship('Product', backref='clothing', uselist=False)

class Groceries(db.Model):
    Product_id = db.Column(db.Integer, db.ForeignKey('product.Product_id'), primary_key=True)
    Expiry_date = db.Column(db.Date)
    Weight = db.Column(db.Float)
    Brand = db.Column(db.String(50))
    product = db.relationship('Product', backref='groceries', uselist=False)

class Electronics(db.Model):
    Product_id = db.Column(db.Integer, db.ForeignKey('product.Product_id'), primary_key=True)
    Warranty = db.Column(db.String(50))
    Brand = db.Column(db.String(50))
    Model = db.Column(db.String(50))
    product = db.relationship('Product', backref='electronics', uselist=False)

class Product(db.Model):
    Product_id = db.Column(db.Integer, primary_key=True)
    Price = db.Column(db.Float, nullable=False)
    Details = db.Column(db.Text)
    Photos = db.Column(db.Text)
    Category = db.Column(db.String(50))
    Ratings = db.Column(db.Float)
    Discount_percentage = db.Column(db.Float)
    GST = db.Column(db.Float)
    cart_items = db.relationship('Contains', backref='product')
    order_items = db.relationship('Includes', backref='product')

class Cart(db.Model):
    Customer_id = db.Column(db.Integer, db.ForeignKey('customer.Customer_id'), primary_key=True)
    Total_product = db.Column(db.Integer)
    Total_cost = db.Column(db.Float)
    Coupon_id = db.Column(db.Integer, db.ForeignKey('coupon.Coupon_id'))
    items = db.relationship('Contains', backref='cart')

class Contains(db.Model):
    Customer_id = db.Column(db.Integer, db.ForeignKey('cart.Customer_id'), primary_key=True)
    Product_id = db.Column(db.Integer, db.ForeignKey('product.Product_id'), primary_key=True)
    Quantity = db.Column(db.Integer)

class Orders(db.Model):
    Order_id = db.Column(db.Integer, primary_key=True)
    Tax = db.Column(db.Float)
    Order_cost = db.Column(db.Float)
    Discount_percentage = db.Column(db.Float)
    items = db.relationship('Includes', backref='order')

class Includes(db.Model):
    Order_id = db.Column(db.Integer, db.ForeignKey('orders.Order_id'), primary_key=True)
    Product_id = db.Column(db.Integer, db.ForeignKey('product.Product_id'), primary_key=True)
    Quantity = db.Column(db.Integer)

class Coupon(db.Model):
    Coupon_id = db.Column(db.Integer, primary_key=True)
    Discount_percentage = db.Column(db.Float)

# Add CustomerOrders model to track which orders belong to which customer
class CustomerOrders(db.Model):
    Order_id = db.Column(db.Integer, db.ForeignKey('orders.Order_id'), primary_key=True)
    Customer_id = db.Column(db.Integer, db.ForeignKey('customer.Customer_id'), primary_key=True)
    order = db.relationship('Orders', backref='customer_orders')
    customer = db.relationship('Customer', backref='orders')

# Routes
@app.route('/')
def index(): 
    sort_by = request.args.get('sort', 'default')  # Get sort parameter from URL
    
    # Base query
    products_query = Product.query
    
    # Apply sorting based on parameter
    if sort_by == 'price_high':
        products = products_query.order_by(Product.Price.desc()).all()
    elif sort_by == 'price_low':
        products = products_query.order_by(Product.Price.asc()).all()
    elif sort_by == 'rating':
        products = products_query.order_by(Product.Ratings.desc()).all()
    else:
        products = products_query.all()
    
    return render_template('index.html', products=products, current_sort=sort_by)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            user_type = request.form.get('user_type')
            print(f"Login attempt - User Type: {user_type}")  # Debug print
            
            if not user_type:
                flash('Please select a user type', 'danger')
                return redirect(url_for('login'))
            
            if user_type == 'customer':
                email = request.form.get('email')
                password = request.form.get('password')
                print(f"Customer login attempt - Email: {email}")  # Debug print
                
                if not email or not password:
                    flash('Please provide both email and password', 'danger')
                    return redirect(url_for('login'))
                
                user = Customer.query.filter_by(Email=email).first()
                if user and user.Password == password:
                    login_user(user)
                    session['user_type'] = 'customer'
                    flash('Welcome back!', 'success')
                    return redirect(url_for('index'))
                else:
                    flash('Invalid email or password', 'danger')
            
            elif user_type == 'employee':
                email = request.form.get('email')
                department = request.form.get('department')
                print(f"Employee login attempt - Email: {email}, Department: {department}")  # Debug print
                
                if not email or not department:
                    flash('Please provide both email and department', 'danger')
                    return redirect(url_for('login'))
                
                user = Employee.query.filter_by(Email=email, Department=department).first()
                if user:
                    login_user(user)
                    session['user_type'] = 'employee'
                    flash('Welcome back!', 'success')
                    return redirect(url_for('employee_dashboard'))
                else:
                    flash('Invalid email or department', 'danger')
            
            elif user_type == 'vendor':
                name = request.form.get('name')
                print(f"Vendor login attempt - Name: {name}")  # Debug print
                
                if not name:
                    flash('Please provide vendor name', 'danger')
                    return redirect(url_for('login'))
                
                user = Vendor.query.filter_by(Name=name).first()
                if user:
                    login_user(user)
                    session['user_type'] = 'vendor'
                    flash('Welcome back!', 'success')
                    return redirect(url_for('vendor_dashboard'))
                else:
                    flash('Invalid vendor name', 'danger')
            
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"Login error: {str(e)}")  # Debug print
            flash(f'An error occurred during login. Please try again.', 'danger')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        user_type = request.form.get('user_type')
        
        try:
            if user_type == 'customer':
                # Check if email already exists
                email = request.form.get('email')
                if Customer.query.filter_by(Email=email).first():
                    flash('Email already exists!', 'danger')
                    return redirect(url_for('signup'))

                customer = Customer(
                    First_Name=request.form.get('first_name'),
                    Last_Name=request.form.get('last_name'),
                    Contact_no=request.form.get('contact'),
                    Email=email,
                    Password=request.form.get('password'),
                    House_No=request.form.get('house_no'),
                    Local_Area=request.form.get('local_area'),
                    Pin_Code=request.form.get('pin_code'),
                    City=request.form.get('city')
                )
                db.session.add(customer)
                flash('Customer account created successfully!', 'success')
                
            elif user_type == 'employee':
                # Check if email already exists
                email = request.form.get('email')
                if Employee.query.filter_by(Email=email).first():
                    flash('Email already exists!', 'danger')
                    return redirect(url_for('signup'))

                employee = Employee(
                    First_Name=request.form.get('first_name'),
                    Last_Name=request.form.get('last_name'),
                    Email=email,
                    Department=request.form.get('department'),
                    City=request.form.get('city'),
                    Pin_Code=request.form.get('pin_code'),
                    House_No=request.form.get('house_no'),
                    Local_Area=request.form.get('local_area'),
                    Date_of_Joining=datetime.strptime(request.form.get('date_of_joining'), '%Y-%m-%d'),
                    Age=int(request.form.get('age')),
                    Date_of_Birth=datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d'),
                    Gender=request.form.get('gender')
                )
                db.session.add(employee)
                flash('Employee account created successfully!', 'success')
                
            elif user_type == 'vendor':
                # Check if vendor name already exists
                name = request.form.get('name')
                if Vendor.query.filter_by(Name=name).first():
                    flash('Vendor name already exists!', 'danger')
                    return redirect(url_for('signup'))

                vendor = Vendor(
                    Name=name,
                    Contact_No=request.form.get('contact_no'),
                    City=request.form.get('city'),
                    Local_Area=request.form.get('local_area'),
                    Pin_Code=request.form.get('pin_code')
                )
                db.session.add(vendor)
                flash('Vendor account created successfully!', 'success')

            db.session.commit()
            return redirect(url_for('login'))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
            return redirect(url_for('signup'))
            
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/cart')
@login_required
def cart():
    cart = Cart.query.filter_by(Customer_id=current_user.Customer_id).first()
    if not cart:
        cart = Cart(Customer_id=current_user.Customer_id, Total_product=0, Total_cost=0)
        db.session.add(cart)
        db.session.commit()
    return render_template('cart.html', cart=cart)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)
    cart = Cart.query.filter_by(Customer_id=current_user.Customer_id).first()
    
    if not cart:
        cart = Cart(Customer_id=current_user.Customer_id, Total_product=0, Total_cost=0)
        db.session.add(cart)
    
    # Check if product already in cart
    contains = Contains.query.filter_by(Customer_id=current_user.Customer_id, Product_id=product_id).first()
    if contains:
        contains.Quantity += 1
    else:
        contains = Contains(Customer_id=current_user.Customer_id, Product_id=product_id, Quantity=1)
        db.session.add(contains)
    
    cart.Total_product += 1
    cart.Total_cost += product.Price
    db.session.commit()
    flash('Product added to cart!', 'success')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    if request.method == 'POST':
        cart = Cart.query.filter_by(Customer_id=current_user.Customer_id).first()
        if not cart or cart.Total_product == 0:
            flash('Your cart is empty!', 'warning')
            return redirect(url_for('cart'))
        
        # Create new order
        order = Orders(
            Tax=0.1 * cart.Total_cost,  # 10% tax
            Order_cost=cart.Total_cost,
            Discount_percentage=0
        )
        db.session.add(order)
        db.session.flush()  # Get the order ID
        
        # Move items from cart to order and store customer info
        for item in cart.items:
            includes = Includes(
                Order_id=order.Order_id,
                Product_id=item.Product_id,
                Quantity=item.Quantity
            )
            db.session.add(includes)
            
        # Store customer information for the order
        customer_order = CustomerOrders(
            Order_id=order.Order_id,
            Customer_id=current_user.Customer_id
        )
        db.session.add(customer_order)
        
        # Clear cart
        cart.Total_product = 0
        cart.Total_cost = 0
        Contains.query.filter_by(Customer_id=current_user.Customer_id).delete()
        db.session.commit()
        
        flash('Order placed successfully!', 'success')
        return redirect(url_for('orders'))
    
    cart = Cart.query.filter_by(Customer_id=current_user.Customer_id).first()
    return render_template('checkout.html', cart=cart)

@app.route('/orders')
@login_required
def orders():
    try:
        # Get all orders for the current customer using CustomerOrders relationship
        customer_orders = db.session.query(Orders)\
            .join(CustomerOrders)\
            .filter(CustomerOrders.Customer_id == current_user.Customer_id)\
            .all()
        
        # Get products for each order
        orders_with_items = []
        for order in customer_orders:
            items = db.session.query(Product, Includes.Quantity)\
                .join(Includes)\
                .filter(Includes.Order_id == order.Order_id)\
                .all()
            orders_with_items.append({
                'order': order,
                'items': items
            })
        
        return render_template('orders.html', orders=orders_with_items)
    except Exception as e:
        # If there's any database error, create tables and show empty orders
        db.create_all()
        flash('Setting up orders system. Please try placing an order.', 'info')
        return render_template('orders.html', orders=[])

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    return render_template('product_detail.html', product=product)

@app.route('/employee/login', methods=['GET', 'POST'])
def employee_login():
    return redirect(url_for('login'))

@app.route('/employee/signup', methods=['GET', 'POST'])
def employee_signup():
    return redirect(url_for('signup'))

@app.route('/vendor/login', methods=['GET', 'POST'])
def vendor_login():
    return redirect(url_for('login'))

@app.route('/vendor/signup', methods=['GET', 'POST'])
def vendor_signup():
    return redirect(url_for('signup'))

@app.route('/employee/dashboard')
@employee_required
def employee_dashboard():
    customers = Customer.query.all()
    unresolved_complaints = Complaint.query.filter(Complaint.Employee_id.is_(None)).all()
    resolved_complaints = Complaint.query.filter(Complaint.Employee_id.isnot(None)).all()
    return render_template('employee_dashboard.html', 
                         customers=customers, 
                         unresolved_complaints=unresolved_complaints,
                         resolved_complaints=resolved_complaints)

@app.route('/employee/handle_complaint/<int:complaint_id>', methods=['POST'])
@employee_required
def handle_complaint(complaint_id):
    complaint = Complaint.query.get_or_404(complaint_id)
    complaint.Employee_id = current_user.Employee_id
    db.session.commit()
    flash('Complaint has been handled successfully!', 'success')
    return redirect(url_for('employee_dashboard'))

@app.route('/vendor/dashboard')
@vendor_required
def vendor_dashboard():
    # Since we don't have Stock and Vendor_id fields, just show all products
    products = Product.query.all()
    return render_template('vendor_dashboard.html', products=products)

@app.route('/vendor/update_stock/<int:product_id>', methods=['POST'])
@vendor_required
def update_stock(product_id):
    flash('Stock management is not available in the current database schema.', 'warning')
    return redirect(url_for('vendor_dashboard'))

@app.route('/customer/complaint', methods=['GET', 'POST'])
@login_required
def submit_complaint():
    if request.method == 'POST':
        order_id = request.form.get('order_id')
        # Verify if the order exists and belongs to the current customer
        order = Orders.query.get(order_id)
        if not order:
            flash('Invalid Order ID. Please check and try again.', 'danger')
            return redirect(url_for('submit_complaint'))

        complaint = Complaint(
            Customer_id=current_user.Customer_id,
            Order_id=order_id
        )
        db.session.add(complaint)
        db.session.commit()
        flash('Complaint submitted successfully!', 'success')
        return redirect(url_for('submit_complaint'))

    # Get customer's previous complaints
    complaints = Complaint.query.filter_by(Customer_id=current_user.Customer_id).all()
    return render_template('submit_complaint.html', complaints=complaints)

@app.route('/vendor/add_product', methods=['GET', 'POST'])
@vendor_required
def add_product():
    if request.method == 'POST':
        try:
            # Create the product
            product = Product(
                Price=float(request.form['price']),
                Details=request.form['details'],
                Photos=request.form['photos'],
                Category=request.form['category'],
                Ratings=float(request.form.get('ratings', 0)),
                Discount_percentage=float(request.form['discount_percentage']),
                GST=float(request.form['gst'])
            )
            db.session.add(product)
            db.session.commit()
            flash('Product added successfully!', 'success')
            return redirect(url_for('vendor_dashboard'))

        except Exception as e:
            db.session.rollback()
            flash(f'Error adding product: {str(e)}', 'danger')
            return redirect(url_for('add_product'))

    return render_template('add_product.html')

@app.route('/vendor/remove_product/<int:product_id>', methods=['POST'])
@vendor_required
def remove_product(product_id):
    try:
        # First remove from specific category table
        product = Product.query.get_or_404(product_id)
        
        if product.Category == 'Clothing':
            Clothing.query.filter_by(Product_id=product_id).delete()
        elif product.Category == 'Electronics':
            Electronics.query.filter_by(Product_id=product_id).delete()
        elif product.Category == 'Groceries':
            Groceries.query.filter_by(Product_id=product_id).delete()

        # Remove from cart items if any
        Contains.query.filter_by(Product_id=product_id).delete()
        
        # Remove from order items if any
        Includes.query.filter_by(Product_id=product_id).delete()
        
        # Finally remove the product
        Product.query.filter_by(Product_id=product_id).delete()
        
        db.session.commit()
        flash('Product removed successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error removing product: {str(e)}', 'danger')
    
    return redirect(url_for('vendor_dashboard'))

if __name__ == '__main__':
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Ensure the CustomerOrders table exists
        inspector = db.inspect(db.engine)
        if 'customer_orders' not in inspector.get_table_names():
            # Create CustomerOrders table explicitly if it doesn't exist
            db.Model.metadata.tables['customer_orders'].create(db.engine)
        
    app.run(debug=True)    
